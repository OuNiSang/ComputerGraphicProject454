names Mike Feng
emails 18wtf@queensu.ca
netIDs 20110114

Comment: 
code note: PASE THIS TO BROWSER[https://mikevon.notion.site/Assignment-1-d893b7a5dc63441c8232eec3662762ae]